package org.jarco.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;

import org.jarco.code.external.IProject;
import org.jarco.code.internal.CodeRepositoryInternal;
import org.jarco.code.internal.maven.MavenRef;
import org.jarco.code.internal.maven.MavenRepositorySPI;
import org.jarco.configuration.Configuration;
import org.jarco.control.report.ControlGReport;
import org.jarco.control.report.DependenciesGReport;
import org.jarco.control.report.TagGReport;
import org.jarco.control.report.ViolationGReport;
import org.jarco.control.report.itf.IDependenciesReport;
import org.jarco.control.specifications.ControlResult;
import org.jarco.control.specifications.model.Specification;
import org.jarco.swing.JReportViewer;
import org.junit.BeforeClass;
import org.junit.Test;
import org.xml.sax.SAXException;

public class TestControl {

	static File tempdir = new File("target/temp");
	
	static
	{
		try
		{
		init();
		}
		catch(Throwable t)
		{
			t.printStackTrace();
		}
	}

	static ControlGReport cfr ;
	static ViolationGReport vr ;
	static TagGReport tr ;
	static IDependenciesReport dr;
	
	@BeforeClass
	public static void init() throws IOException, IllegalArgumentException, SecurityException, XPathExpressionException, ClassNotFoundException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, SAXException, TransformerException
	{
		dr = new DependenciesGReport(tempdir,"test-analysis");
		
		Properties p = new Properties();
		p.load(new FileInputStream("TestAnalysis.conf.properties"));
		String repoPath = p.getProperty("repoPath");
		String jdkPath = p.getProperty("jdkPath");
		
		MavenRef[] mr = new MavenRef[]{
				new MavenRef(repoPath,"org.jarco","test-analysis", "0.1-SNAPSHOT","jar")
		};
		MavenRepositorySPI mrspi = new MavenRepositorySPI(dr,repoPath,mr);
		final CodeRepositoryInternal cr=new CodeRepositoryInternal(
				dr,
				jdkPath,
				mrspi
		);
		cr.flush();
		
		TagRepositoryDeTest trepo = new TagRepositoryDeTest();
		SpecficationDeTest es = new SpecficationDeTest(trepo);
		
		for(MavenRef mri : mr)
		{
			IProject prj = cr.findProject(mri,true);
		}
		
		cfr = new ControlGReport(tempdir,"test-analysis");
		vr = new ViolationGReport(tempdir,"test-analysis");
		ControlResult ctr = new ControlResult(cfr,vr);
		es.visit(cr, ctr);
		tr = new TagGReport(tempdir,"test-analysis");
		trepo.report(tr);
		dr.close();
		vr.getReport();
		
	}
	
	@Test
	public void testDependencies()
	{
	}
	@Test
	public void testControl()
	{
		
	}
	@Test 
	public void testTags()
	{
		
	}
	@Test
	public void testViolations()
	{
		
	}
}
