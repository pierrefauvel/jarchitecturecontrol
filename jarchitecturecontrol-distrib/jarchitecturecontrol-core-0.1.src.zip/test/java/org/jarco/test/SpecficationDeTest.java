package org.jarco.test;

import org.jarco.code.external.ICodeRepository;
import org.jarco.code.external.IProject;
import org.jarco.control.specifications.model.FollowProductionRule;
import org.jarco.control.specifications.model.NamePredicate;
import org.jarco.control.specifications.model.Specification;
import org.jarco.control.specifications.model.TagAffectation;

public class SpecficationDeTest extends Specification<ICodeRepository> {

	private TagRepositoryDeTest test;
	
	public SpecficationDeTest(TagRepositoryDeTest test) {
		this.test=test;
		
		Specification s_projets = new Specification( new FollowProductionRule ("Projects"));
		addChildSpec(s_projets);
		
		Specification s_projet = new Specification(
				new FollowProductionRule("Projects"),
				new NamePredicate("test-analysis-","version",""));
		addChildSpec(s_projet);
		Specification s_packages = new Specification(
				new FollowProductionRule("Packages"),
				new NamePredicate("org.jarco.test.analysis")
		);
		s_projet.addChildSpec(s_packages);
		Specification s_p_classes = new Specification(
				new FollowProductionRule("Classes")
		);
		s_packages.addChildSpec(s_p_classes);
		s_p_classes.addConsequence(new TagAffectation(test,test.myTag));
	}

}
