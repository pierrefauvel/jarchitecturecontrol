package org.jarco.test;

import org.jarco.tags.external.ITagType;
import org.jarco.tags.internal.TagInternal;
import org.jarco.tags.internal.TagRepositoryInternal;

public class TagRepositoryDeTest extends TagRepositoryInternal {
	public ITagType myTag ;
	public TagRepositoryDeTest()
	{
		myTag = this.newTagType("myTag");
	}
	
	
}
