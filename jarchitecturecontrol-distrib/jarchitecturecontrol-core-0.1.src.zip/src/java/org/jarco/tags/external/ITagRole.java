package org.jarco.tags.external;

public interface ITagRole {
	public ITagRoleType getType();
	public ITagAssociation getAssociation();
	public ITag getTag();
}
