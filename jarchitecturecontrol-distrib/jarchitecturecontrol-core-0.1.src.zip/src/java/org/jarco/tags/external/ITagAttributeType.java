package org.jarco.tags.external;

import org.jarco.code.external.INamed;

public interface ITagAttributeType extends INamed{
	public ITagType getType();
}
