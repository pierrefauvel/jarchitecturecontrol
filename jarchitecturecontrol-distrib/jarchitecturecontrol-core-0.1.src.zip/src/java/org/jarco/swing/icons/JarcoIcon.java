package org.jarco.swing.icons;

public class JarcoIcon {

}
