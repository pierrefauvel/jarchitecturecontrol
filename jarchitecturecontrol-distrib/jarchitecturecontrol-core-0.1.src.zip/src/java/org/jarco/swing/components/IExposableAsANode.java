package org.jarco.swing.components;

import org.jarco.persistence.IPersistableAsXml;

public interface IExposableAsANode extends IPersistableAsXml{

	String toLabel();
}
