package org.jarco.swing.tree;

public interface IExposableAsANode {

	String toLabel();
	String toXml();
}
