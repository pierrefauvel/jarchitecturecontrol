package org.jarco.code.external;


public interface IAnnotation extends INamed{ 
}
