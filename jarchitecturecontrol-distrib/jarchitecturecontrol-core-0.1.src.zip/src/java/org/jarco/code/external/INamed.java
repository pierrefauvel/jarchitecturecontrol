package org.jarco.code.external;

public interface INamed {
	public String getName();
}
