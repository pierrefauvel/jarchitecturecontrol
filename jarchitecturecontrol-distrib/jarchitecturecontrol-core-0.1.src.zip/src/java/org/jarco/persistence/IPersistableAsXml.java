package org.jarco.persistence;

//0.1 revoir la logique. le from XML doit etre une methode d'instance + constructeur vide. On peut du coup l'ajouter � l'interface
public interface IPersistableAsXml {
	String toXml();
}
